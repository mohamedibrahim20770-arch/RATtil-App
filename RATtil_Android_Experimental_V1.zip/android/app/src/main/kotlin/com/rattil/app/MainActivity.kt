package com.rattil.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
