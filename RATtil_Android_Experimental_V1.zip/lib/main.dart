import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:http/http.dart' as http;
import 'package:audioplayers/audioplayers.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const RATtilApp());
}

class RATtilApp extends StatelessWidget {
  const RATtilApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'رَتِّل - RATtil',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar', 'AE'),
      supportedLocales: const [
        Locale('ar', 'AE'),
      ],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0A1128),
        primaryColor: const Color(0xFF1B2A4A),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF3B82F6),
          secondary: Color(0xFFD4AF37),
          surface: Color(0xFF162238),
        ),
        fontFamily: 'Amiri',
      ),
      home: const SplashScreen(),
    );
  }
}

// ==================== SplashScreen ====================
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 3), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const HomeScreen()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A1128),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: const Color(0xFFD4AF37), width: 2),
                color: const Color(0xFF162238),
              ),
              child: const Icon(
                Icons.menu_book_rounded,
                size: 64,
                color: Color(0xFFD4AF37),
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
              style: TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.bold,
                color: Color(0xFFD4AF37),
                fontFamily: 'Amiri',
              ),
              textDirection: TextDirection.rtl,
            ),
            const SizedBox(height: 16),
            const Text(
              'رَتِّل',
              style: TextStyle(
                fontSize: 32,
                fontWeight: FontWeight.bold,
                color: Colors.white,
                letterSpacing: 2,
              ),
              textDirection: TextDirection.rtl,
            ),
            const SizedBox(height: 30),
            const CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFD4AF37)),
            ),
          ],
        ),
      ),
    );
  }
}

// ==================== Data Models ====================
class Surah {
  final int number;
  final String name;
  final String englishName;
  final int numberOfAyahs;

  Surah({
    required this.number,
    required this.name,
    required this.englishName,
    required this.numberOfAyahs,
  });

  factory Surah.fromJson(Map<String, dynamic> json) {
    return Surah(
      number: json['number'],
      name: json['name'],
      englishName: json['englishName'],
      numberOfAyahs: json['numberOfAyahs'],
    );
  }
}

class Ayah {
  final int number;
  final String text;
  final int numberInSurah;

  Ayah({
    required this.number,
    required this.text,
    required this.numberInSurah,
  });

  factory Ayah.fromJson(Map<String, dynamic> json) {
    return Ayah(
      number: json['number'],
      text: json['text'],
      numberInSurah: json['numberInSurah'],
    );
  }
}

class Reciter {
  final String id;
  final String name;
  final String identifier;

  Reciter({required this.id, required this.name, required this.identifier});
}

// ==================== HomeScreen ====================
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Surah> _surahs = [];
  Surah? _selectedSurah;
  int _selectedAyahNumber = 1;
  int _totalAyahs = 7;
  bool _isLoadingSurahs = true;
  String _errorMessage = '';

  final List<Reciter> _reciters = [
    Reciter(id: 'ar.husary', name: 'الشيخ محمود خليل الحصري', identifier: 'ar.husary'),
    Reciter(id: 'ar.abdulbasit', name: 'الشيخ عبد الباسط عبد الصمد', identifier: 'ar.abdulbasit'),
    Reciter(id: 'ar.minshawi', name: 'الشيخ محمد صديق المنشاوي', identifier: 'ar.minshawi'),
  ];
  late Reciter _selectedReciter;

  @override
  void initState() {
    super.initState();
    _selectedReciter = _reciters[0];
    _fetchSurahs();
  }

  Future<void> _fetchSurahs() async {
    setState(() {
      _isLoadingSurahs = true;
      _errorMessage = '';
    });
    try {
      final response = await http.get(Uri.parse('https://api.alquran.cloud/v1/surah'));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        List list = data['data'];
        setState(() {
          _surahs = list.map((e) => Surah.fromJson(e)).toList();
          if (_surahs.isNotEmpty) {
            _selectedSurah = _surahs[0];
            _totalAyahs = _selectedSurah!.numberOfAyahs;
          }
          _isLoadingSurahs = false;
        });
      } else {
        setState(() {
          _errorMessage = 'فشل تحميل السور. يرجى التحقق من الاتصال بالإنترنت.';
          _isLoadingSurahs = false;
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'خطأ في الاتصال: $e';
        _isLoadingSurahs = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            'رَتِّل - القرآن الكريم',
            style: TextStyle(fontFamily: 'Amiri', fontWeight: FontWeight.bold, color: Color(0xFFD4AF37)),
          ),
          backgroundColor: const Color(0xFF162238),
          centerTitle: true,
          elevation: 0,
        ),
        body: _isLoadingSurahs
            ? const Center(
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFD4AF37)),
                ),
              )
            : _errorMessage.isNotEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.wifi_off, size: 64, color: Colors.orangeAccent),
                          const SizedBox(height: 16),
                          Text(
                            _errorMessage,
                            textAlign: TextAlign.center,
                            style: const TextStyle(fontSize: 16, color: Colors.white70),
                          ),
                          const SizedBox(height: 24),
                          ElevatedButton.icon(
                            onPressed: _fetchSurahs,
                            icon: const Icon(Icons.refresh),
                            label: const Text('إعادة المحاولة'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF3B82F6),
                              foregroundColor: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),
                  )
                : SingleChildScrollView(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        // Reciter Selection Card
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: const Color(0xFF162238),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: const Color(0xFF3B82F6).withOpacity(0.3)),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'اختر القارئ المفضلة:',
                                style: TextStyle(color: Color(0xFFD4AF37), fontWeight: FontWeight.bold, fontSize: 16),
                              ),
                              const SizedBox(height: 8),
                              DropdownButtonHideUnderline(
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 12),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF0A1128),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: DropdownButton<Reciter>(
                                    value: _selectedReciter,
                                    isExpanded: true,
                                    dropdownColor: const Color(0xFF162238),
                                    items: _reciters.map((reciter) {
                                      return DropdownMenuItem(
                                        value: reciter,
                                        child: Text(reciter.name, style: const TextStyle(color: Colors.white)),
                                      );
                                    }).toList(),
                                    onChanged: (val) {
                                      if (val != null) {
                                        setState(() {
                                          _selectedReciter = val;
                                        });
                                      }
                                    },
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),

                        // Surah & Ayah Selection Card
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: const Color(0xFF162238),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: const Color(0xFF3B82F6).withOpacity(0.3)),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'اختر السورة ورقم الآية:',
                                style: TextStyle(color: Color(0xFFD4AF37), fontWeight: FontWeight.bold, fontSize: 16),
                              ),
                              const SizedBox(height: 12),
                              // Surah Dropdown
                              DropdownButtonHideUnderline(
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 12),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF0A1128),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: DropdownButton<Surah>(
                                    value: _selectedSurah,
                                    isExpanded: true,
                                    dropdownColor: const Color(0xFF162238),
                                    items: _surahs.map((surah) {
                                      return DropdownMenuItem(
                                        value: surah,
                                        child: Text(
                                          '${surah.number}. سورة ${surah.name} (${surah.numberOfAyahs} آية)',
                                          style: const TextStyle(color: Colors.white),
                                        ),
                                      );
                                    }).toList(),
                                    onChanged: (val) {
                                      if (val != null) {
                                        setState(() {
                                          _selectedSurah = val;
                                          _totalAyahs = val.numberOfAyahs;
                                          _selectedAyahNumber = 1;
                                        });
                                      }
                                    },
                                  ),
                                ),
                              ),
                              const SizedBox(height: 12),
                              // Ayah Number Dropdown
                              Row(
                                children: [
                                  const Text('رقم الآية:', style: TextStyle(color: Colors.white70)),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 12),
                                      decoration: BoxDecoration(
                                        color: const Color(0xFF0A1128),
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                      child: DropdownButtonHideUnderline(
                                        child: DropdownButton<int>(
                                          value: _selectedAyahNumber > _totalAyahs ? 1 : _selectedAyahNumber,
                                          isExpanded: true,
                                          dropdownColor: const Color(0xFF162238),
                                          items: List.generate(_totalAyahs, (index) => index + 1).map((ayahNum) {
                                            return DropdownMenuItem(
                                              value: ayahNum,
                                            child: Text('الآية $ayahNum', style: const TextStyle(color: Colors.white)),
                                            );
                                          }).toList(),
                                          onChanged: (val) {
                                            if (val != null) {
                                              setState(() {
                                                _selectedAyahNumber = val;
                                              });
                                            }
                                          },
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 24),

                        // Action Buttons
                        _buildActionButton(
                          title: 'قراءة القرآن الكريم',
                          icon: Icons.menu_book,
                          color: const Color(0xFF3B82F6),
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => ReaderScreen(
                                  initialSurah: _selectedSurah!,
                                  initialAyahNumber: _selectedAyahNumber,
                                  reciter: _selectedReciter,
                                ),
                              ),
                            );
                          },
                        ),
                        const SizedBox(height: 12),
                        _buildActionButton(
                          title: 'الاستماع للآية',
                          icon: Icons.volume_up_rounded,
                          color: const Color(0xFF1E3A8A),
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => AudioPlayerScreen(
                                  surah: _selectedSurah!,
                                  ayahNumber: _selectedAyahNumber,
                                  reciter: _selectedReciter,
                                ),
                              ),
                            );
                          },
                        ),
                        const SizedBox(height: 12),
                        _buildActionButton(
                          title: 'الحفظ والتسميع بالميكروفون',
                          icon: Icons.mic_rounded,
                          color: const Color(0xFFD4AF37),
                          textColor: const Color(0xFF0A1128),
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => RecitationScreen(
                                  surah: _selectedSurah!,
                                  ayahNumber: _selectedAyahNumber,
                                  reciter: _selectedReciter,
                                ),
                              ),
                            );
                          },
                        ),
                        const SizedBox(height: 12),
                        _buildActionButton(
                          title: 'مراجعة الحفظ',
                          icon: Icons.replay_rounded,
                          color: const Color(0xFF1B2A4A),
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => ReviewScreen(
                                  surah: _selectedSurah!,
                                  reciter: _selectedReciter,
                                ),
                              ),
                            );
                          },
                        ),
                        const SizedBox(height: 12),
                        _buildActionButton(
                          title: 'ذكّرني (التلميح الصوتي والمرئي)',
                          icon: Icons.lightbulb_outline_rounded,
                          color: const Color(0xFF2563EB),
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => RemindMeScreen(
                                  surah: _selectedSurah!,
                                  ayahNumber: _selectedAyahNumber,
                                  reciter: _selectedReciter,
                                ),
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
      ),
    );
  }

  Widget _buildActionButton({
    required String title,
    required IconData icon,
    required Color color,
    Color textColor = Colors.white,
    required VoidCallback onPressed,
  }) {
    return SizedBox(
      height: 56,
      child: ElevatedButton.icon(
        onPressed: onPressed,
        icon: Icon(icon, color: textColor),
        label: Text(
          title,
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: textColor, fontFamily: 'Amiri'),
        ),
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          elevation: 2,
        ),
      ),
    );
  }
}

// ==================== ReaderScreen ====================
class ReaderScreen extends StatefulWidget {
  final Surah initialSurah;
  final int initialAyahNumber;
  final Reciter reciter;

  const ReaderScreen({
    super.key,
    required this.initialSurah,
    required this.initialAyahNumber,
    required this.reciter,
  });

  @override
  State<ReaderScreen> createState() => _ReaderScreenState();
}

class _ReaderScreenState extends State<ReaderScreen> {
  bool _isLoading = true;
  List<Ayah> _ayahs = [];
  String _errorMessage = '';

  @override
  void initState() {
    super.initState();
    _fetchAyahs();
  }

  Future<void> _fetchAyahs() async {
    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });
    try {
      final response = await http.get(
        Uri.parse('https://api.alquran.cloud/v1/surah/${widget.initialSurah.number}'),
      );
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        List list = data['data']['ayahs'];
        setState(() {
          _ayahs = list.map((e) => Ayah.fromJson(e)).toList();
          _isLoading = false;
        });
      } else {
        setState(() {
          _errorMessage = 'فشل تحميل الآيات.';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'خطأ في الاتصال: $e';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text('سورة ${widget.initialSurah.name}', style: const TextStyle(fontFamily: 'Amiri', color: Color(0xFFD4AF37))),
          backgroundColor: const Color(0xFF162238),
          centerTitle: true,
        ),
        body: _isLoading
            ? const Center(child: CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFD4AF37))))
            : _errorMessage.isNotEmpty
                ? Center(child: Text(_errorMessage, style: const TextStyle(color: Colors.white70)))
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: _ayahs.length,
                    itemBuilder: (context, index) {
                      final ayah = _ayahs[index];
                      final isHighlighted = ayah.numberInSurah == widget.initialAyahNumber;
                      return Container(
                        margin: const EdgeInsets.only(bottom: 16),
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: isHighlighted ? const Color(0xFF1E3A8A).withOpacity(0.4) : const Color(0xFF162238),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: isHighlighted ? const Color(0xFFD4AF37) : const Color(0xFF3B82F6).withOpacity(0.2),
                            width: isHighlighted ? 2 : 1,
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF0A1128),
                                    borderRadius: BorderRadius.circular(6),
                                    border: Border.all(color: const Color(0xFFD4AF37)),
                                  ),
                                  child: Text(
                                    'الآية ${ayah.numberInSurah}',
                                    style: const TextStyle(color: Color(0xFFD4AF37), fontWeight: FontWeight.bold),
                                  ),
                                ),
                                IconButton(
                                  icon: const Icon(Icons.volume_up, color: Color(0xFF3B82F6)),
                                  onPressed: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => AudioPlayerScreen(
                                          surah: widget.initialSurah,
                                          ayahNumber: ayah.numberInSurah,
                                          reciter: widget.reciter,
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            Text(
                              ayah.text,
                              style: const TextStyle(
                                fontSize: 22,
                                height: 1.8,
                                color: Colors.white,
                                fontFamily: 'Amiri',
                              ),
                              textAlign: TextAlign.right,
                            ),
                          ],
                        ),
                      );
                    },
                  ),
      ),
    );
  }
}

// ==================== AudioPlayerScreen ====================
class AudioPlayerScreen extends StatefulWidget {
  final Surah surah;
  final int ayahNumber;
  final Reciter reciter;

  const AudioPlayerScreen({
    super.key,
    required this.surah,
    required this.ayahNumber,
    required this.reciter,
  });

  @override
  State<AudioPlayerScreen> createState() => _AudioPlayerScreenState();
}

class _AudioPlayerScreenState extends State<AudioPlayerScreen> {
  final AudioPlayer _audioPlayer = AudioPlayer();
  bool _isPlaying = false;
  bool _isLoading = true;
  String _audioUrl = '';
  String _ayahText = '';

  @override
  void initState() {
    super.initState();
    _loadAudioAndAyah();
  }

  Future<void> _loadAudioAndAyah() async {
    setState(() {
      _isLoading = true;
    });
    try {
      // Fetch Ayah text
      final response = await http.get(
        Uri.parse('https://api.alquran.cloud/v1/surah/${widget.surah.number}'),
      );
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        List ayahs = data['data']['ayahs'];
        final target = ayahs.firstWhere(
          (a) => a['numberInSurah'] == widget.ayahNumber,
          orElse: () => ayahs[0],
        );
        _ayahText = target['text'];
      }

      // Construct audio URL using EveryAyah / AlQuran Cloud standard audio URL format
      // Format: https://everyayah.com/data/{Reciter_Folder}/{Surah3Digits}{Ayah3Digits}.mp3
      String folder = '';
      if (widget.reciter.identifier == 'ar.husary') {
        folder = 'Mahmoud_Khaleel_Al-Husaree_128kbps';
      } else if (widget.reciter.identifier == 'ar.abdulbasit') {
        folder = 'Abdul_Basit_Murattal_192kbps';
      } else {
        folder = 'Minshawy_Murattal_128kbps';
      }

      String sStr = widget.surah.number.toString().padLeft(3, '0');
      String aStr = widget.ayahNumber.toString().padLeft(3, '0');
      _audioUrl = 'https://everyayah.com/data/$folder/$sStr$aStr.mp3';

      await _audioPlayer.play(UrlSource(_audioUrl));
      setState(() {
        _isPlaying = true;
        _isLoading = false;
      });

      _audioPlayer.onPlayerStateChanged.listen((state) {
        if (mounted) {
          setState(() {
            _isPlaying = state == PlayerState.playing;
          });
        }
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  void dispose() {
    _audioPlayer.stop();
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text('الاستماع للآية - سورة ${widget.surah.name}', style: const TextStyle(fontFamily: 'Amiri', color: Color(0xFFD4AF37))),
          backgroundColor: const Color(0xFF162238),
          centerTitle: true,
        ),
        body: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFF162238),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFFD4AF37)),
                ),
                child: Column(
                  children: [
                    Text(
                      'القارئ: ${widget.reciter.name}',
                      style: const TextStyle(color: Color(0xFFD4AF37), fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'سورة ${widget.surah.name} - الآية ${widget.ayahNumber}',
                      style: const TextStyle(color: Colors.white70),
                    ),
                    const SizedBox(height: 16),
                    _isLoading
                        ? const CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFD4AF37)))
                        : Text(
                            _ayahText.isNotEmpty ? _ayahText : 'جاري تحميل الآية...',
                            style: const TextStyle(fontSize: 22, height: 1.8, color: Colors.white, fontFamily: 'Amiri'),
                            textAlign: TextAlign.center,
                          ),
                  ],
                ),
              ),
              const SizedBox(height: 40),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(
                    iconSize: 64,
                    color: const Color(0xFF3B82F6),
                    icon: Icon(_isPlaying ? Icons.pause_circle_filled : Icons.play_circle_filled),
                    onPressed: () async {
                      if (_isPlaying) {
                        await _audioPlayer.pause();
                      } else {
                        await _audioPlayer.resume();
                      }
                    },
                  ),
                  const SizedBox(width: 24),
                  IconButton(
                    iconSize: 48,
                    color: Colors.white70,
                    icon: const Icon(Icons.stop_circle),
                    onPressed: () async {
                      await _audioPlayer.stop();
                      setState(() {
                        _isPlaying = false;
                      });
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ==================== RecitationScreen ====================
class RecitationScreen extends StatefulWidget {
  final Surah surah;
  final int ayahNumber;
  final Reciter reciter;

  const RecitationScreen({
    super.key,
    required this.surah,
    required this.ayahNumber,
    required this.reciter,
  });

  @override
  State<RecitationScreen> createState() => _RecitationScreenState();
}

class _RecitationScreenState extends State<RecitationScreen> {
  final stt.SpeechToText _speech = stt.SpeechToText();
  bool _isListening = false;
  String _spokenText = 'اضغط على زر الميكروفون وابدأ التسميع...';
  String _targetAyahText = '';
  bool _isLoading = true;
  double _confidence = 0.0;

  @override
  void initState() {
    super.initState();
    _fetchTargetAyah();
  }

  Future<void> _fetchTargetAyah() async {
    try {
      final response = await http.get(
        Uri.parse('https://api.alquran.cloud/v1/surah/${widget.surah.number}'),
      );
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        List ayahs = data['data']['ayahs'];
        final target = ayahs.firstWhere(
          (a) => a['numberInSurah'] == widget.ayahNumber,
          orElse: () => ayahs[0],
        );
        setState(() {
          _targetAyahText = target['text'];
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
        _targetAyahText = 'تعذر جلب الآية.';
      });
    }
  }

  void _startListening() async {
    bool available = await _speech.initialize(
      onStatus: (status) => print('onStatus: $status'),
      onError: (error) => print('onError: $error'),
    );
    if (available) {
      setState(() {
        _isListening = true;
        _spokenText = 'جاري الاستماع... اشرع في القراءة';
      });
      _speech.listen(
        localeId: 'ar_SA',
        onResult: (result) {
          setState(() {
            _spokenText = result.recognizedWords;
            if (result.hasConfidenceRating && result.confidence > 0) {
              _confidence = result.confidence;
            }
          });
        },
      );
    } else {
      setState(() {
        _spokenText = 'خدمة التعرف الصوتي غير متاحة أو مرفوضة الصلاحية.';
      });
    }
  }

  void _stopListening() async {
    await _speech.stop();
    setState(() {
      _isListening = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('الحفظ والتسميع بالميكروفون', style: TextStyle(fontFamily: 'Amiri', color: Color(0xFFD4AF37))),
          backgroundColor: const Color(0xFF162238),
          centerTitle: true,
        ),
        body: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFF162238),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFF3B82F6).withOpacity(0.3)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'سورة ${widget.surah.name} - الآية ${widget.ayahNumber}',
                      style: const TextStyle(color: Color(0xFFD4AF37), fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                    const SizedBox(height: 8),
                    _isLoading
                        ? const CircularProgressIndicator()
                        : Text(
                            _targetAyahText,
                            style: const TextStyle(fontSize: 20, height: 1.6, color: Colors.white, fontFamily: 'Amiri'),
                          ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFF0A1128),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: const Color(0xFFD4AF37).withOpacity(0.5)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'ما قمت بتسميعه:',
                        style: TextStyle(color: Colors.white70, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 12),
                      Expanded(
                        child: SingleChildScrollView(
                          child: Text(
                            _spokenText,
                            style: TextStyle(
                              fontSize: 18,
                              color: _isListening ? const Color(0xFF3B82F6) : Colors.white,
                              fontFamily: 'Amiri',
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'ملاحظة: هذه نسخة تجريبية للتعرف الصوتي (Speech Recognition) وقد تحتوي على اختلافات بسيطة مقارنة بالرسم العثماني.',
                style: TextStyle(color: Colors.grey, fontSize: 12),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 20),
              Center(
                child: GestureDetector(
                  onTap: _isListening ? _stopListening : _startListening,
                  child: Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _isListening ? Colors.redAccent : const Color(0xFF3B82F6),
                      boxShadow: [
                        BoxShadow(
                          color: (_isListening ? Colors.redAccent : const Color(0xFF3B82F6)).withOpacity(0.5),
                          blurRadius: 10,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: Icon(
                      _isListening ? Icons.mic : Icons.mic_none,
                      size: 40,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Center(
                child: Text(
                  _isListening ? 'جاري الاستماع... اضغط للإيقاف' : 'اضغط للبدء في التسميع',
                  style: const TextStyle(color: Colors.white70),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ==================== ReviewScreen ====================
class ReviewScreen extends StatefulWidget {
  final Surah surah;
  final Reciter reciter;

  const ReviewScreen({super.key, required this.surah, required this.reciter});

  @override
  State<ReviewScreen> createState() => _ReviewScreenState();
}

class _ReviewScreenState extends State<ReviewScreen> {
  bool _isLoading = true;
  List<Ayah> _ayahs = [];
  int _currentIndex = 0;
  bool _showAnswer = false;

  @override
  void initState() {
    super.initState();
    _fetchAyahs();
  }

  Future<void> _fetchAyahs() async {
    try {
      final response = await http.get(
        Uri.parse('https://api.alquran.cloud/v1/surah/${widget.surah.number}'),
      );
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        List list = data['data']['ayahs'];
        setState(() {
          _ayahs = list.map((e) => Ayah.fromJson(e)).toList();
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text('مراجعة سورة ${widget.surah.name}', style: const TextStyle(fontFamily: 'Amiri', color: Color(0xFFD4AF37))),
          backgroundColor: const Color(0xFF162238),
          centerTitle: true,
        ),
        body: _isLoading
            ? const Center(child: CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFD4AF37))))
            : _ayahs.isEmpty
                ? const Center(child: Text('لا توجد آيات متاحة.', style: TextStyle(color: Colors.white70)))
                : Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: const Color(0xFF162238),
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: const Color(0xFFD4AF37)),
                          ),
                          child: Column(
                            children: [
                              Text(
                                'الآية رقم ${_ayahs[_currentIndex].numberInSurah}',
                                style: const TextStyle(color: Color(0xFFD4AF37), fontWeight: FontWeight.bold, fontSize: 18),
                              ),
                              const SizedBox(height: 20),
                              _showAnswer
                                  ? Text(
                                      _ayahs[_currentIndex].text,
                                      style: const TextStyle(fontSize: 22, height: 1.8, color: Colors.white, fontFamily: 'Amiri'),
                                      textAlign: TextAlign.center,
                                    )
                                  : const Text(
                                      'اضغط على زر "إظهار الآية" لتسميعها في ذهنيك ثم التحقق منها.',
                                      style: TextStyle(color: Colors.white70, fontSize: 16),
                                      textAlign: TextAlign.center,
                                    ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 30),
                        ElevatedButton.icon(
                          onPressed: () {
                            setState(() {
                              _showAnswer = !_showAnswer;
                            });
                          },
                          icon: Icon(_showAnswer ? Icons.visibility_off : Icons.visibility),
                          label: Text(_showAnswer ? 'إخفاء الآية' : 'إظهار الآية'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF3B82F6),
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            textStyle: const TextStyle(fontSize: 18, fontFamily: 'Amiri'),
                          ),
                        ),
                        const SizedBox(height: 12),
                        ElevatedButton(
                          onPressed: () {
                            setState(() {
                              if (_currentIndex < _ayahs.length - 1) {
                                _currentIndex++;
                              } else {
                                _currentIndex = 0;
                              }
                              _showAnswer = false;
                            });
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF1B2A4A),
                            padding: const EdgeInsets.symmetric(vertical: 14),
                          ),
                          child: const Text(
                            'الآية التالية للمراجعة',
                            style: TextStyle(fontSize: 18, fontFamily: 'Amiri', color: Color(0xFFD4AF37)),
                          ),
                        ),
                      ],
                    ),
                  ),
      ),
    );
  }
}

// ==================== RemindMeScreen ====================
class RemindMeScreen extends StatefulWidget {
  final Surah surah;
  final int ayahNumber;
  final Reciter reciter;

  const RemindMeScreen({
    super.key,
    required this.surah,
    required this.ayahNumber,
    required this.reciter,
  });

  @override
  State<RemindMeScreen> createState() => _RemindMeScreenState();
}

class _RemindMeScreenState extends State<RemindMeScreen> {
  bool _isLoading = true;
  String _hintText = '';
  final AudioPlayer _audioPlayer = AudioPlayer();

  @override
  void initState() {
    super.initState();
    _fetchHint();
  }

  Future<void> _fetchHint() async {
    try {
      final response = await http.get(
        Uri.parse('https://api.alquran.cloud/v1/surah/${widget.surah.number}'),
      );
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        List ayahs = data['data']['ayahs'];
        final target = ayahs.firstWhere(
          (a) => a['numberInSurah'] == widget.ayahNumber,
          orElse: () => ayahs[0],
        );
        String fullText = target['text'];
        // Show first few words as hint
        List<String> words = fullText.split(' ');
        String hint = words.take(3).join(' ') + ' ...';
        setState(() {
          _hintText = hint;
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
        _hintText = 'تعذر جلب التلميح.';
      });
    }
  }

  void _playAudioHint() async {
    String folder = '';
    if (widget.reciter.identifier == 'ar.husary') {
      folder = 'Mahmoud_Khaleel_Al-Husaree_128kbps';
    } else if (widget.reciter.identifier == 'ar.abdulbasit') {
      folder = 'Abdul_Basit_Murattal_192kbps';
    } else {
      folder = 'Minshawy_Murattal_128kbps';
    }
    String sStr = widget.surah.number.toString().padLeft(3, '0');
    String aStr = widget.ayahNumber.toString().padLeft(3, '0');
    String url = 'https://everyayah.com/data/$folder/$sStr$aStr.mp3';
    await _audioPlayer.play(UrlSource(url));
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('ذكّرني (التلميح)', style: TextStyle(fontFamily: 'Amiri', color: Color(0xFFD4AF37))),
          backgroundColor: const Color(0xFF162238),
          centerTitle: true,
        ),
        body: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: const Color(0xFF162238),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: const Color(0xFFD4AF37)),
                ),
                child: Column(
                  children: [
                    const Icon(Icons.lightbulb, color: Color(0xFFD4AF37), size: 48),
                    const SizedBox(height: 16),
                    Text(
                      'سورة ${widget.surah.name} - الآية ${widget.ayahNumber}',
                      style: const TextStyle(color: Color(0xFFD4AF37), fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                    const SizedBox(height: 20),
                    _isLoading
                        ? const CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFD4AF37)))
                        : Text(
                            _hintText,
                            style: const TextStyle(fontSize: 24, height: 1.8, color: Colors.white, fontFamily: 'Amiri'),
                            textAlign: TextAlign.center,
                          ),
                  ],
                ),
              ),
              const SizedBox(height: 30),
              ElevatedButton.icon(
                onPressed: _playAudioHint,
                icon: const Icon(Icons.volume_up, color: Color(0xFF0A1128)),
                label: const Text('تشغيل التلميح الصوتي من القارئ'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFD4AF37),
                  foregroundColor: const Color(0xFF0A1128),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, fontFamily: 'Amiri'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
